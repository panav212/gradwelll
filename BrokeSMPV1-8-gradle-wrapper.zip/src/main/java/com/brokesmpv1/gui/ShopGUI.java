package com.brokesmpv1.gui;

import com.brokesmpv1.BrokeSMPV1;
import com.brokesmpv1.shards.ShardType;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;

public class ShopGUI implements Listener {

    private static final String TITLE = "§bShard Shop";

    public static void open(Player p, BrokeSMPV1 plugin){
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        int i = 0;
        for (ShardType t : ShardType.values()){
            if (i>=18) break;
            ItemStack it = t.getItem(1);
            ItemMeta m = it.getItemMeta();
            java.util.List<String> lore = (m.hasLore()?m.getLore():new java.util.ArrayList<>());
            lore.add(" ");
            lore.add("§7Left Click: §eBuy Tier 1 (" + t.getPriceTier(1) + ")");
            lore.add("§7Right Click: §eBuy Tier 2 (" + t.getPriceTier(2) + ")");
            lore.add("§7Shift+Right: §eBuy Tier 3 (" + t.getPriceTier(3) + ")");
            m.setLore(lore);
            it.setItemMeta(m);
            inv.setItem(i++, it);
        }
        // Extra Ability Upgrade token (Essence)
        ItemStack core = new ItemStack(Material.NETHER_STAR);
        ItemMeta cm = core.getItemMeta();
        cm.setDisplayName("§dExtra Ability Core");
        cm.setLore(java.util.Arrays.asList(
            "§7Unlocks 4th ability for your current shard.",
            "§7Cost: §d10 Essence",
            "§8Click to purchase"
        ));
        core.setItemMeta(cm);
        inv.setItem(26, core);

        p.openInventory(inv);
        Bukkit.getPluginManager().registerEvents(new ShopGUIListener(plugin), plugin);
    }

    private static class ShopGUIListener implements Listener {
        private final BrokeSMPV1 plugin;
        public ShopGUIListener(BrokeSMPV1 plugin){ this.plugin = plugin; }

        @EventHandler
        public void onClick(InventoryClickEvent e){
            if (!TITLE.equals(e.getView().getTitle())) return;
            e.setCancelled(true);
            if (!(e.getWhoClicked() instanceof Player p)) return;
            ItemStack clicked = e.getCurrentItem();
            if (clicked == null || clicked.getType() == Material.AIR) return;

            // Extra ability core
            if (clicked.getType() == Material.NETHER_STAR){
                if (plugin.economy().spendEssence(p, 10)){
                    plugin.shards().unlockExtra(p);
                    p.sendMessage("§dExtra ability unlocked for your equipped shard!");
                } else {
                    p.sendMessage("§cNot enough essence.");
                }
                p.closeInventory();
                return;
            }

            for (ShardType t : ShardType.values()){
                if (t.isSameItem(clicked)){
                    int tier = 1;
                    if (e.isRightClick() && !e.isShiftClick()) tier = 2;
                    if (e.isRightClick() && e.isShiftClick()) tier = 3;
                    int price = t.getPriceTier(tier);
                    if (plugin.economy().takeCoins(p, price)){
                        plugin.shards().giveShard(p, t, tier);
                        p.sendMessage("§aPurchased §e" + t.getDisplayName() + " §7(Tier " + tier + ") §afor §e" + price);
                    } else {
                        p.sendMessage("§cNot enough coins.");
                    }
                    p.closeInventory();
                    return;
                }
            }
        }
    }
}
