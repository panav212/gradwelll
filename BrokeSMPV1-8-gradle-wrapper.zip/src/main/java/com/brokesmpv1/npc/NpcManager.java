package com.brokesmpv1.npc;

import com.brokesmpv1.BrokeSMPV1;
import com.brokesmpv1.gui.ShopGUI;
import com.brokesmpv1.gui.TaskGUI;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.*;
import org.bukkit.event.*;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.persistence.*;

public class NpcManager implements Listener {

    private final BrokeSMPV1 plugin;
    private final NamespacedKey key;

    public NpcManager(BrokeSMPV1 plugin){
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "npc_type");
    }

    public void spawnTaskNpc(Location loc){
        spawnNpc(loc, "TASK", "§a§lBank (Tasks)");
    }

    public void spawnShopNpc(Location loc){
        spawnNpc(loc, "SHOP", "§b§lShard Shop");
    }

    private void spawnNpc(Location loc, String type, String name){
        Villager v = loc.getWorld().spawn(loc, Villager.class);
        v.setAI(false);
        v.setInvulnerable(true);
        v.setCustomName(name);
        v.setCustomNameVisible(true);
        v.getPersistentDataContainer().set(key, PersistentDataType.STRING, type);
    }

    @EventHandler
    public void onInteract(PlayerInteractEntityEvent e){
        if (!(e.getRightClicked() instanceof Villager v)) return;
        String type = v.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (type == null) return;
        e.setCancelled(true);
        Player p = e.getPlayer();
        if (type.equals("TASK")){
            TaskGUI.open(p, plugin.tasks());
        } else if (type.equals("SHOP")){
            ShopGUI.open(p, plugin);
        }
    }
}
