package com.brokesmpv1.shards;

import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public enum ShardType {

    INFERNO_BLADE("§cInferno Blade", Material.BLAZE_POWDER, 9001, 500, 1500, 3000,
            new String[]{"§7On Hit: §cBurn 5s", "§8Kill unlock: Resistance 5s"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){ public void onHit(Player p, Entity v){ v.setFireTicks(5*20); }},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 5*20, 0)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 8*20, 0)); }}
            }),

    VAMPIRE_DAGGER("§4Vampire Dagger", Material.REDSTONE, 9002, 400, 1200, 2400,
            new String[]{"§7On Hit: §cHeal 30% of damage"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){ public void onHit(Player p, Entity v){ if (v instanceof LivingEntity le){ double heal = Math.max(0, le.getLastDamage())*0.3; p.setHealth(Math.min(p.getMaxHealth(), p.getHealth()+heal)); }}},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 4*20, 0)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 10*20, 1)); }}
            }),

    STORMBREAKER_AXE("§bStormbreaker Axe", Material.HEART_OF_THE_SEA, 9003, 500, 1500, 3000,
            new String[]{"§7On Hit: §bLightning Strike"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){ public void onHit(Player p, Entity v){ v.getWorld().strikeLightning(v.getLocation()); }},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 5*20, 1)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, 6*20, 0)); }}
            }),

    FROSTBRAND("§3Frostbrand", Material.BLUE_ICE, 9004, 400, 1200, 2400,
            new String[]{"§7On Hit: §bSlow 50% for 4s"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){ public void onHit(Player p, Entity v){ if (v instanceof LivingEntity le){ le.addPotionEffect(new PotionEffect(PotionEffectType.SLOW, 4*20, 1)); } }},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, 10*20, 0)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, 10*20, 0)); }}
            }),

    WITHER_SCYTHE("§8Wither Scythe", Material.WITHER_SKELETON_SKULL, 9005, 600, 1800, 3600,
            new String[]{"§7On Hit: §8Wither II 3s"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){ public void onHit(Player p, Entity v){ if (v instanceof LivingEntity le){ le.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, 3*20, 1)); } }},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 5*20, 0)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, 6*20, 0)); }}
            }),

    SHADOW_KATANA("§0Shadow Katana", Material.ENDER_PEARL, 9006, 400, 1400, 2600,
            new String[]{"§7Passive: Invisibility 5s after kill"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, 5*20, 0)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 6*20, 1)); }}
            }),

    PHOENIX_BOW("§6Phoenix Bow", Material.BOW, 9007, 500, 1500, 3000,
            new String[]{"§7Passive: Flaming arrows"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 10*20, 0)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE, 10*20, 0)); }}
            }),

    ZEPHYR_BLADE("§fZephyr Blade", Material.FEATHER, 9008, 300, 1000, 2000,
            new String[]{"§7On Hit: chance Speed II 5s"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){ public void onHit(Player p, Entity v){ if (Math.random()<0.4) p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 5*20, 1)); }},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 5*20, 1)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 6*20, 0)); }}
            }),

    EARTHSPLITTER_HAMMER("§2Earthsplitter Hammer", Material.ANVIL, 9009, 600, 1600, 3200,
            new String[]{"§7On Hit: Shockwave knockback"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){ public void onHit(Player p, Entity v){ for (Entity e : p.getNearbyEntities(5,3,5)){ if (e instanceof LivingEntity le && !e.equals(p)){ le.setVelocity(le.getLocation().toVector().subtract(p.getLocation().toVector()).normalize().multiply(0.8).setY(0.3)); } }}},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.DAMAGE_RESISTANCE, 6*20, 0)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.INCREASE_DAMAGE, 5*20, 0)); }}
            }),

    CELESTIAL_SPEAR("§dCelestial Spear", Material.PRISMARINE_SHARD, 9010, 500, 1500, 3000,
            new String[]{"§7On Hit: Small dash forward"},
            new ShardAbility[]{
                new ShardAbility(ShardAbility.Trigger.PASSIVE){},
                new ShardAbility(ShardAbility.Trigger.HIT){ public void onHit(Player p, Entity v){ p.setVelocity(p.getLocation().getDirection().normalize().multiply(0.6).setY(0.1)); }},
                new ShardAbility(ShardAbility.Trigger.KILL){ public void onKill(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.SLOW_FALLING, 6*20, 0)); }},
                new ShardAbility(ShardAbility.Trigger.EXTRA){ public void onExtra(Player p, Entity v){ p.addPotionEffect(new PotionEffect(PotionEffectType.CONDUIT_POWER, 10*20, 0)); }}
            });

    private final String display;
    private final Material mat;
    private final int cmd;
    private final int price1, price2, price3;
    private final String[] lore;
    private final ShardAbility[] abilities;

    ShardType(String display, Material mat, int cmd, int p1, int p2, int p3, String[] lore, ShardAbility[] ab){
        this.display = display; this.mat = mat; this.cmd = cmd;
        this.price1 = p1; this.price2 = p2; this.price3 = p3;
        this.lore = lore; this.abilities = ab;
    }

    public String getDisplayName(){ return display; }
    public int getPriceTier(int tier){ return tier==1?price1:(tier==2?price2:price3); }

    public ItemStack getItem(int tier){
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName(display + " §7(T" + tier + ")");
        java.util.List<String> l = new java.util.ArrayList<>();
        l.addAll(java.util.Arrays.asList(lore));
        l.add("§7Tier "+tier+" abilities active");
        m.setLore(l);
        m.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
        m.setCustomModelData(cmd);
        it.setItemMeta(m);
        return it;
    }

    public ItemStack getRecipeIcon(){
        ItemStack it = new ItemStack(mat);
        ItemMeta m = it.getItemMeta();
        m.setDisplayName("§6" + strip(display) + " §7Recipe");
        m.setLore(java.util.Arrays.asList(
            "§7• Ingredient A",
            "§7• Ingredient B",
            "§7• Ingredient C",
            " ",
            "§8(Recipes are informational; buy in Shop NPC)"
        ));
        m.setCustomModelData(cmd);
        it.setItemMeta(m);
        return it;
    }

    public boolean isSameItem(ItemStack other){
        if (other == null || other.getType()!=mat) return false;
        if (!other.hasItemMeta() || !other.getItemMeta().hasDisplayName()) return false;
        return other.getItemMeta().getDisplayName().contains(strip(display));
    }

    public static String[] names(){ return java.util.Arrays.stream(values()).map(Enum::name).toArray(String[]::new); }
    private static String strip(String s){ return s.replaceAll("§.", ""); }

    public void applyPassive(Player p){ abilities[0].onPassive(p); }
    public void applyHit(Player p, Entity v){ abilities[1].onHit(p, v); }
    public void applyKill(Player p, Entity v){ abilities[2].onKill(p, v); }
    public void applyExtra(Player p, Entity v){ abilities[3].onExtra(p, v); }
}
