package com.brokesmpv1.commands;

import com.brokesmpv1.gui.RecipeGUI;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public class RecipeCommand implements CommandExecutor {
    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player p)){ sender.sendMessage("Players only."); return true; }
        RecipeGUI.open(p);
        return true;
    }
}
